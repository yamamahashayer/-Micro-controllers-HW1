#include "my_adc.h"

void init_adc_no_lib(void) {
      ADCON1=0b00001100;
    ADCON0 = 0;
    ADCON0bits.ADON = 1; // turn adc on 
    ADCON2 = 0b10001001; // ADFM= 1 right justified 10 bits, 2 Tad, Fosc/8


}

// reads the adc and returns a 16 bit value ( 10 bit )
// returns value 0--1023

int read_adc_raw_no_lib(unsigned char channel) {
     int raw_value; 
    ADCON0bits.CHS = channel;
    ADCON0bits.GO = 1; 
    while (ADCON0bits.GO) {}; 
    raw_value = ADRESH << 8 | ADRESL;     
    return raw_value;
}

float read_adc_voltage(unsigned char channel) {
    int raw_value;
    float voltage;
    raw_value = read_adc_raw_no_lib(channel);
    voltage = (raw_value * 5) / 1023.0;
    return voltage;
}

