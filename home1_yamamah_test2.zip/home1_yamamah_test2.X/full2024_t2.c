

/*
 * File:   newmain.c
 * Author: hp
 *
 * Created on October 15, 2024, 9:01 PM
 */
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// PIC18F4620 Configuration Bit Settings

// 'C' source line config statements

// CONFIG1H
#pragma config OSC = RCIO6      // Oscillator Selection bits (External RC oscillator, port function on RA6)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enable bit (Fail-Safe Clock Monitor disabled)
#pragma config IESO = OFF       // Internal/External Oscillator Switchover bit (Oscillator Switchover mode disabled)

// CONFIG2L
#pragma config PWRT = OFF       // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = SBORDIS  // Brown-out Reset Enable bits (Brown-out Reset enabled in hardware only (SBOREN is disabled))
#pragma config BORV = 3         // Brown Out Reset Voltage bits (Minimum setting)

// CONFIG2H
#pragma config WDT = ON         // Watchdog Timer Enable bit (WDT enabled)
#pragma config WDTPS = 32768    // Watchdog Timer Postscale Select bits (1:32768)

// CONFIG3H
#pragma config CCP2MX = PORTC   // CCP2 MUX bit (CCP2 input/output is multiplexed with RC1)
#pragma config PBADEN = ON      // PORTB A/D Enable bit (PORTB<4:0> pins are configured as analog input channels on Reset)
#pragma config LPT1OSC = OFF    // Low-Power Timer1 Oscillator Enable bit (Timer1 configured for higher power operation)
#pragma config MCLRE = ON       // MCLR Pin Enable bit (MCLR pin enabled; RE3 input pin disabled)

// CONFIG4L
#pragma config STVREN = ON      // Stack Full/Underflow Reset Enable bit (Stack full/underflow will cause Reset)
#pragma config LVP = ON         // Single-Supply ICSP Enable bit (Single-Supply ICSP enabled)
#pragma config XINST = OFF      // Extended Instruction Set Enable bit (Instruction set extension and Indexed Addressing mode disabled (Legacy mode))

// CONFIG5L
#pragma config CP0 = OFF        // Code Protection bit (Block 0 (000800-003FFFh) not code-protected)
#pragma config CP1 = OFF        // Code Protection bit (Block 1 (004000-007FFFh) not code-protected)
#pragma config CP2 = OFF        // Code Protection bit (Block 2 (008000-00BFFFh) not code-protected)
#pragma config CP3 = OFF        // Code Protection bit (Block 3 (00C000-00FFFFh) not code-protected)

// CONFIG5H
#pragma config CPB = OFF        // Boot Block Code Protection bit (Boot block (000000-0007FFh) not code-protected)
#pragma config CPD = OFF        // Data EEPROM Code Protection bit (Data EEPROM not code-protected)

// CONFIG6L
#pragma config WRT0 = OFF       // Write Protection bit (Block 0 (000800-003FFFh) not write-protected)
#pragma config WRT1 = OFF       // Write Protection bit (Block 1 (004000-007FFFh) not write-protected)
#pragma config WRT2 = OFF       // Write Protection bit (Block 2 (008000-00BFFFh) not write-protected)
#pragma config WRT3 = OFF       // Write Protection bit (Block 3 (00C000-00FFFFh) not write-protected)

// CONFIG6H
#pragma config WRTC = OFF       // Configuration Register Write Protection bit (Configuration registers (300000-3000FFh) not write-protected)
#pragma config WRTB = OFF       // Boot Block Write Protection bit (Boot Block (000000-0007FFh) not write-protected)
#pragma config WRTD = OFF       // Data EEPROM Write Protection bit (Data EEPROM not write-protected)

// CONFIG7L
#pragma config EBTR0 = OFF      // Table Read Protection bit (Block 0 (000800-003FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR1 = OFF      // Table Read Protection bit (Block 1 (004000-007FFFh) not protected from table reads executed in other blocks)
#pragma config EBTR2 = OFF      // Table Read Protection bit (Block 2 (008000-00BFFFh) not protected from table reads executed in other blocks)
#pragma config EBTR3 = OFF      // Table Read Protection bit (Block 3 (00C000-00FFFFh) not protected from table reads executed in other blocks)

// CONFIG7H
#pragma config EBTRB = OFF      // Boot Block Table Read Protection bit (Boot Block (000000-0007FFh) not protected from table reads executed in other blocks)

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define _XTAL_FREQ 4000000UL // Define the clock frequency
#include <xc.h>
#include <stdio.h>
#include <string.h>
#include "my_ser.h"
#include "my_adc.h"
#include "lcd_x8.h"
#define STARTVALUE  3036

void reloadTimer1(void);
void delay_ms(unsigned int n);
void changeMode(void);
void selectSetupOption(void);
void checkCurrentMode(void);
void processSerialCommand(char receivedChar); // ser command
void sendTime(void); // sertime
void   sendTemperature(void); // serial temp
void   sendHeaterCoolerStatus(void); // H C serial
void writeTime(char* buffer); // writ time in serial
void toggleHeater(void);
void display(void);
void writeTime(char *buffer);
unsigned char isValidTimeFormat(char *buffer);
unsigned char isDigit(char c);
void setupPorts(void);
void checkFormate(void);

unsigned char sec = 0;
unsigned char min = 0;
unsigned char hour = 0;
//unsigned short sec1=0;
//unsigned short min1=0;
//unsigned short hour1=0;
unsigned char setup_option = 0; // 0 = Seconds, 1 = Minutes, 2 = Hours

#define MODE_SETUP 0   
#define MODE_NORMAL 1  

unsigned char currentMode = MODE_NORMAL;
unsigned char heaterStatus = 0;  // 0 = OFF, 1 = ON
unsigned char coolerStatus = 0;  // 0 = OFF, 1 = ON

char Buffer[32]; 
float AN[3];     
int raw_val;
unsigned char channel;
float voltage; 
float temp,tempf;

void reloadTimer1(void)
{  
    TMR1H = (unsigned char) ((STARTVALUE >>  8) & 0x00FF);
    TMR1L =  (unsigned char)(STARTVALUE & 0x00FF );   
}

void clock(void)
{
    sec++ ;
    if(sec == 60) 
    {  
        min++;
        sec=0;
    }
    if(min == 60) 
    { 
        hour++;
        min=0;
    }
    if(hour == 24) 
    { 
        hour = 0;
    }
    reloadTimer1();
}

void __interrupt(high_priority) highIsr(void) {
    if (INTCONbits.TMR0IF) {
        clock(); 
        INTCONbits.TMR0IF = 0;     
    } else if (INTCON3bits.INT1IF) {
        __delay_ms(50);
        changeMode(); 
        INTCON3bits.INT1IF = 0;
    } else if (INTCON3bits.INT2IF) {
        __delay_ms(50);
         if (!PORTBbits.RB2 && currentMode == MODE_SETUP) { 
            __delay_ms(100);
            selectSetupOption();
            INTCON3bits.INT2IF = 0;
        }
        
         else  INTCON3bits.INT2IF = 0;
    }
    
    // iterrupt for Cooler
    else if (INTCONbits.INT0IF) {
        __delay_ms(50); 
        if (!PORTBbits.RB0) {
            LATCbits.LATC2 = !LATCbits.LATC2; 
            if (LATCbits.LATC2) {
                coolerStatus=1;
                send_string_no_lib((unsigned char *)"Cooler ON\r\n");
            } else {
                coolerStatus=0;
                send_string_no_lib((unsigned char *)"Cooler OFF\r\n");
            }
            while (!PORTBbits.RB0); // wait until RB0 is free
        }
        INTCONbits.INT0IF = 0; 
    }

    // interrupt for ser command
    if (PIR1bits.RCIF) { // data from ser
        char receivedChar = read_byte_no_lib(); // read char
        processSerialCommand(receivedChar); // proccessing char
        PIR1bits.RCIF = 0; // clr iterrupt flag
    }
}

void toggleHeater(void) {
    if (!PORTBbits.RB4) { // pressed  RB4
        __delay_ms(100); 
        if (!PORTBbits.RB4) {
            if (heaterStatus == 0) {
                heaterStatus = 1;
                PORTCbits.RC5 = 1; //operate
                send_string_no_lib((unsigned char *)"Heater ON\r\n");
            } else {
                heaterStatus = 0;
                PORTCbits.RC5 = 0; //stop
                send_string_no_lib((unsigned char *)"Heater OFF\r\n");
            }
            while (!PORTBbits.RB4); // wait until RB4 is free
        }
    }
}
int commandComplete = 0; 
void clearBuffer(char *buffer, int length) {
    for (int i = 0; i < length; i++) {
        buffer[i] = '\0';
    }
}

void processSerialCommand(char receivedChar) {
    static int bufferIndex = 0;
    static char serialBuffer[10] = {0}; // Buffer to store "HH:MM:SS"
    static int receivingTime = 0; // Flag to indicate if we are receiving time

    
        if (!receivingTime) {
              
            
        if (receivedChar == 'w') {
               send_string_no_lib((unsigned char *)"Command 'w' received, starting to receive time values...\r\n");
               char timeStr[9]; 
               int j = 0;
               while (j < 8) {
                   if (PIR1bits.RCIF) {
                       timeStr[j] = read_byte_no_lib();
                       j++;
                   }
                   CLRWDT(); 
               }
               timeStr[8] = '\0';  

               if (timeStr[2] == ':' && timeStr[5] == ':') {
                   int h = (timeStr[0] - '0') * 10 + (timeStr[1] - '0');
                   int m = (timeStr[3] - '0') * 10 + (timeStr[4] - '0');
                   int s = (timeStr[6] - '0') * 10 + (timeStr[7] - '0');
                   if (h >= 0 && h < 24 && m >= 0 && m < 60 && s >= 0 && s < 60) {
                       hour = h;
                       min = m;
                       sec = s;
                       send_string_no_lib("Time updated successfully\r\n");
                   } else {
                       send_string_no_lib("Invalid time values\r\n");
                   }
               } else {
                   send_string_no_lib("Invalid time format\r\n");
               }
        }  
                
                
                
         else if (receivedChar == 't') {
            send_string_no_lib((unsigned char *)"Command 't' received, sending time...\r\n");
            sendTime();
        } else if (receivedChar == 'T') {
            send_string_no_lib((unsigned char *)"Command 'T' received, sending temperature...\r\n");
            sendTemperature();
        } else if (receivedChar == 's') {
            send_string_no_lib((unsigned char *)"Command 's' received, sending heater and cooler status...\r\n");
            sendHeaterCoolerStatus();
        } else {
            // Unknown command
            send_string_no_lib((unsigned char *)"Unknown command received\r\n");
        }

        // Reset buffer in case of unknown or unrelated commands
        bufferIndex = 0;
        clearBuffer(serialBuffer, sizeof(serialBuffer));
    }
}


void sendTime() {
    char timeString[20];
    sprintf(timeString, "Time: %02d:%02d:%02d\r\n", hour, min, sec);
    send_string_no_lib((unsigned char*)timeString);
}

void sendTemperature() {
    char tempString[20];
    sprintf(tempString, "T: %4.2f\r\n", temp);
    send_string_no_lib((unsigned char*)tempString);
}

void sendHeaterCoolerStatus() {
    char statusString[30];
    sprintf(statusString, "Heater: %s\r\nCooler: %s\r\n", 
            heaterStatus ? "ON" : "OFF", 
            coolerStatus ? "ON" : "OFF");
    send_string_no_lib((unsigned char*)statusString);
}



void selectSetupOption(void) {
    setup_option = (setup_option + 1) % 3; // ????? ??????? ??? ???????? (0, 1, 2)
    send_string_no_lib((unsigned char *)"select Setup Option \r\n");
}

void changeMode(void) {
    if (currentMode == MODE_NORMAL) { 
        currentMode = MODE_SETUP;
        T0CONbits.TMR0ON = 0;  // ????? Timer0
        send_string_no_lib((unsigned char *)" ...setup mode... \r\n");
        __delay_ms(200); 
    } else {
        currentMode = MODE_NORMAL;
        T0CONbits.TMR0ON = 1;  // ????? Timer0
        send_string_no_lib((unsigned char *)" ...normal mode... \r\n");
        __delay_ms(200); 
    }
}


void display() {
    char LCD[64];
    unsigned char* C, * H;

    // ??? ????? ??????
    lcd_gotoxy(1, 1);
    sprintf(LCD, "%02d:%02d:%02d ", hour, min, sec); 
    lcd_puts(LCD);

    lcd_gotoxy(2, 4);
    lcd_puts("yamamah_Shifaa");

    // ???? ??????
    if (heaterStatus == 1) {
        H = "ON   ";
    } else {
        H = "OFF  ";
    }

    // ???? ??????
    if (coolerStatus == 1) {
        C = "ON      ";
    } else {
        C = "OFF    ";
    }

    // ??? ???? ?????? ???????
    lcd_gotoxy(1, 2);
    sprintf(LCD, "H ");
    lcd_puts(LCD);
    
    lcd_gotoxy(8, 2);
    sprintf(LCD, "C ");
    lcd_puts(LCD);
    
    lcd_gotoxy(3, 2);
    lcd_puts(H);
    
    lcd_gotoxy(10, 2);
    lcd_puts(C);

   
    lcd_gotoxy(1, 3); 
    
    if (currentMode == MODE_SETUP) 
    {
            if (setup_option == 0) {
              lcd_puts("Setup Sec     "); 
               __delay_ms(200);
        } else if (setup_option == 1) {
            lcd_puts("Setup Minutes   ");
             __delay_ms(200);
        } else if (setup_option == 2) {
            lcd_puts("Setup Hours    ");
             __delay_ms(200);
        } 
           // lcd_puts("Setup");
    } 
    else 
    {
        
        lcd_puts("Normal          ");
    }
}

void delay_ms(unsigned int n) {
    while (n--) {
        __delay_ms(1); // Adjust based on your clock settings
    }
}

void setupPorts(void) {
    ADCON0 =0;
    ADCON1 = 0x0F; //all digital
    TRISB = 0xFF; // ???? ??????? ??????
    TRISC = 0x80; // RX ????? ?????? ??????
    TRISA = 0xFF; // ???? ??????
    TRISD = 0x00; // ???? ??????
    TRISE= 0x00;  // ???? ??????
    setupSerial(); // ????? ??????? ????????
}

void main(void) { 
    setupPorts();
    setupSerial();
    lcd_init();
    init_adc_no_lib();
    TRISCbits.TRISC2 = 0; // RC2 ???? (?????? ?? ??????)
    TRISCbits.TRISC5 = 0; // RC5 ???? (?????? ?? ??????)
    LATCbits.LATC2 = 0;   // ????? ??????
    LATCbits.LATC5 = 0;  

    send_string_no_lib((unsigned char *)"start...\r\n");

    INTCON = 0; 
    RCONbits.IPEN = 0;
   
    INTCON3 = 0;
    T0CON = 0b10000011; // Timer0, 16-bit, prescaler 1:16
    PORTD = 0;

    reloadTimer1(); 
   
    INTCONbits.TMR0IE = 1;    
    INTCONbits.INT0IE = 1; // Enable INT0 external interrupt
    INTCON3bits.INT1IE = 1; // Enable INT1 external interrupt
    INTCON3bits.INT2IE = 1; // Enable INT2 external interrupt (for RB2)
    INTCON2bits.INTEDG0 = 1; // INT0 on rising edge
    INTCON2bits.INTEDG1 = 1; // INT1 on rising edge
    INTCON2bits.INTEDG2 = 1; // INT2 on rising edge
    INTCONbits.INT0IF = 0;
    INTCON3bits.INT1IF = 0; 
    INTCON3bits.INT2IF = 0;
    INTCONbits.GIEH = 1; // Enable high-priority interrupts
    INTCONbits.GIEL = 1; // Enable low-priority interrupts

    T0CONbits.TMR0ON = 1;
    lcd_send_byte(0, 1);  

    while (1) {  
        CLRWDT();  
        tempf = read_adc_voltage(2);
        temp = tempf * 100.0;
        lcd_gotoxy(10, 1);
        sprintf(Buffer, "%4.2fC ", temp);
        lcd_puts(Buffer);
        
        // ???? ?? ??? Setup ??????/????? ?????
        if (currentMode == MODE_SETUP) {
            // ???? ?? ?? RB3 ?????? ?????
            if (!PORTBbits.RB3) {
                send_string_no_lib((unsigned char *)"RB3 for increment \r\n");
                __delay_ms(200); // Debounce delay
                if (!PORTBbits.RB3) {
                    if (setup_option == 0) { // ????? ???????
                        sec++;
                        if (sec == 60) { sec = 0; min++; }
                    } else if (setup_option == 1) { // ????? ???????
                        min++;
                        if (min == 60) { min = 0; hour++; }
                    } else if (setup_option == 2) { // ????? ???????
                        hour++;
                        if (hour == 24) { hour = 0; }
                    }
                    send_string_no_lib((unsigned char *)"Time incremented \r\n");
                    delay_ms(300); // ????? ??? ??????? ???????
                }
            }

            // ???? ?? ?? RB5 ?????? ?????
            if (!PORTBbits.RB5) {
                send_string_no_lib((unsigned char *)"RB5 for decrement \r\n");
                __delay_ms(200); // Debounce delay
                if (!PORTBbits.RB5) {
                    if (setup_option == 0 && sec > 0) { // ????? ???????
                        sec--;
                        if (sec == 255) { sec = 59; min--; }
                    } else if (setup_option == 1 && min > 0) { // ????? ???????
                        min--;
                        if (min == 255) { min = 59; hour--; }
                    } else if (setup_option == 2 && hour > 0) { // ????? ???????
                        hour--;
                        if (hour == 255) { hour = 23; }
                    }
                    send_string_no_lib((unsigned char *)"Time decremented \r\n");
                    delay_ms(300); // ????? ??? ??????? ??????
                }
            }
        }

        toggleHeater(); // ?????? ?? ??????
        display(); // ????? ?????
     
    } 
}

